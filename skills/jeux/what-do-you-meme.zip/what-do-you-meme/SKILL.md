---
name: "what-do-you-meme"
description: "Arbitrer ou animer une partie de What Do You Meme? (version FR) : rappeler les règles, tenir les scores, juger les manches, gérer cartes Freestyle et variantes."
---

# What Do You Meme? — maître du jeu

Utilise ce skill quand Gabriel joue à What Do You Meme? (édition française, cartes-texte + cartes-image) et veut que Claude explique une règle, tranche un litige, tienne le score ou serve de juge-arbitre d'appoint.

## Règles de référence (résumé de la notice)

**Mise en place**
- 3 joueurs minimum (soi + 2 amis ou plus).
- Mélanger les cartes-texte ; chaque joueur en reçoit 7.
- Optionnel : retirer les cartes marquées « 18+ » avant de commencer.
- Premier juge-arbitre : le joueur avec le plus de followers Instagram. Clause humoristique : s'il a acheté ses followers ou abuse des hashtags, il est destitué (et paie sa tournée) ; le joueur à sa droite prend sa place.

**Déroulé d'une manche**
1. Le juge-arbitre choisit 1 carte-image, la montre et la pose sur le chevalet, visible de tous.
2. Chaque autre joueur choisit dans sa main la carte-texte qui colle le mieux à l'image.
3. Les cartes sont remises **face cachée** au juge.
4. Le juge les mélange, les lit **à voix haute** et les pose face visible ; l'image reste visible pendant la lecture.
5. Le juge désigne le texte le plus adapté / drôle / déjanté. Son auteur gagne la carte-image (= 1 point).
6. Tous les joueurs défaussent leurs cartes-texte et en reçoivent **7 nouvelles**.
7. Le joueur à **gauche** du juge devient le nouveau juge-arbitre.

**Fin de partie**
- Dès qu'un joueur atteint **20 points** (ou quand tout le monde a faim).
- Le joueur avec le plus de cartes-image gagne.

**Règles supplémentaires**
- **Carte Freestyle** : celui qui l'a doit la jouer immédiatement face visible. Tous les autres défaussent leurs 7 cartes-texte et **inventent leur propre texte** pour la manche (écrit et glissé au juge, ou lu à voix haute à tour de rôle).
- **Main pourrie** : un joueur peut échanger une carte-image déjà gagnée (−1 point) contre 7 nouvelles cartes-texte.
- **Variante** : utiliser ses propres photos (mèmes sur le dos des amis).

## Ce que Claude fait

- **Rappel de règle / litige** : répondre court, en citant la règle ci-dessus. Si la notice ne tranche pas, le dire et proposer une règle maison simple, à valider par la table.
- **Tenue des scores** : garder un tableau joueur → points, l'ordre de passage du juge (sens horaire, vers la gauche) et signaler quand quelqu'un atteint 20.
- **Juge d'appoint** : si on décrit l'image et qu'on lit les textes, choisir un gagnant en une phrase, avec un brin d'humour, sans connaître les auteurs.
- **Manche Freestyle / variante photo** : proposer quelques légendes originales si on le demande (jamais recopier les textes des cartes du commerce).
- Ton : léger, rapide, adapté à une soirée entre amis ; format court lisible sur téléphone.
- Respecter les préférences de la table sur le contenu 18+.